<?php
return [
    'fields_not_accepted' => 'Coloanele :field nu sunt acceptate în căutare.'
];
