<?php
namespace Prettus\Repository\Generators;

use Exception;

/**
 * Class FileAlreadyExistsException
 * @package Prettus\Repository\Generators
 */
class FileAlreadyExistsException extends Exception
{
}