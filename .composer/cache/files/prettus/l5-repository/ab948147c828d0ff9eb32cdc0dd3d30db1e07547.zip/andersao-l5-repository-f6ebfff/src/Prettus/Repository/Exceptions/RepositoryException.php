<?php
namespace Prettus\Repository\Exceptions;

use Exception;

/**
 * Class RepositoryException
 * @package Prettus\Repository\Exceptions
 */
class RepositoryException extends Exception
{

}
